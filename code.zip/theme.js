// theme/themeConfig.ts
const theme = {
  token: {
    fontSize: 16,
    colorPrimary: '#1356DB',
  },
};

export default theme;
export const Editorial = () => {
  return <div>Editorial</div>;
};

export const Solutions = () => {
  return <div>Solutions</div>;
};

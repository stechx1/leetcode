export const Submissions = () => {
  return <div>Submissions</div>;
};
